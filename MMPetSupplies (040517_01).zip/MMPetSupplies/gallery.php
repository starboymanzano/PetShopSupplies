<?php 
	session_start();
	include("functions.php");
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Gallery - M&M Pet Supplies</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- If computer has running through internet
		<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="custom-css/custom.css">
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	-->
	
	<!-- If computer doesn't access internet -->
	    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="custom-css/custom.css">
	    <script src="bootstrap-3.3.7-dist/js/jquery.min.js"></script>
	    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</head>

<body style="background-color: #ECECEC;">
	<nav class="navbar navbar-inverse lewis-header">
		<div class="container">

			<!--logo -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="index.php" class="navbar-left"><img src="media/header.png"></a>
			</div>

			<!--menu-items -->
			<div class="collapse navbar-collapse" id="mainNavBar">
				<?php 
	
					if(isset($_SESSION['cust_user'])){
					echo "<ul class='nav navbar-nav'><li>
						<form method='get' action='results.php' role='search' class='navbar-form col-xs-12' enctype='multipart/form-data'>
						<input name='search' type='search' class='form-control' placeholder='Search from shop'/>
						<input name='search-btn' type='submit' class='btn btn-primary' value='Search'/>
						</form>
						</li></ul>";
					} else {
						//Oh yeah!
					}
					?>

				<!--right align -->
				<ul class="nav navbar-nav navbar-right">
					<li><a href="index.php">Home</a></li>
				
					<!--drop down menu -->
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Info <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<?php 
								if(isset($_SESSION['cust_user'])) {
									echo "<li><a href='#contact' data-toggle='modal'>Contact</a></li>";
								} else {
									//No Codes
								}
							?>
							<li><a href="feedback.php">Feedbacks</a></li>
							<li><a href="about.php">About Us</a></li>
							<li class="active"><a href="gallery.php">Gallery</a></li>
						</ul>
					</li>
					<?php
						if (isset($_SESSION['cust_user'])) {
							echo "<li><a href='shop.php'>Shop</a></li>";
						} else {
							echo "<li><a href='#login' data-toggle='modal'>Shop</a></li>";
						}
					?>
				
					<li><a href="#">Cart</a></li>

					<!--drop down menu -->
					<?php 
						if (!isset($_SESSION['cust_user'])) {
	    					echo "<li><a href='#login' data-toggle='modal'>Login/Register</a></li>";
						 } else {
						 	echo "<li class='dropdown'>
							<a href='#'' class='dropdown-toggle' data-toggle='dropdown'>Hi, " . $_SESSION['cust_user'] . "<span class='caret'></span></a>
							<ul class='dropdown-menu'>
							<li><a href='myaccount.php'>Account Page</a></li>
							<li><a href='logout.php'>Logout</a></li>
							</ul>
							</li>";
						 }
					 ?>
				</ul>

			</div>
		</div>
	</nav>

	<div class="container">
		<div class="row">
			<div class="col-md-10">
				<ul class="breadcrumb">
					<li><a href="index.php">Home</a></li>
					<li class="disabled">Information Section</li>
					<li class="active">Gallery</li>						
				</ul>
				<div class="panel panel-default" style="background-color: #DADFE1;">
					
					<div class="panel-body">
					
						<div class="page-header">
							<h1><small>M&M Gallery (Images are proof that we're legit online pet supplies seller!)</small></h1>
						</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-12">
								<?php getGallery(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>

			<?php /* Ads Section */ include("includes/ads.php"); ?>

		
	</div>
	</div>
	
	<div class="modal fade" id="login" role="dialog">
	<div class="modal-dialog">
				<div class="modal-content">
					<form role="form" class="form-horizontal" method="post">
					<div class="modal-header">
						<h4 style="margin-left: 10px;">You need to Login before accessing the shop</h4>
					</div>
					
					<div class="modal-body">
					<div class="alert alert-info">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times</a>Don't have an account? Register <a href="registration.php">here</a>
					</div>
						<div class="input-group input-group-lg">
			 			 <span class="input-group-addon" id="sizing-addon1">@</span>
			  			<input type="text" class="form-control" placeholder="Username" aria-describedby="sizing-addon1" name="cust_user" required>
					</div><br/>			
					<div class="input-group input-group-lg">
			 			 <span class="input-group-addon" id="sizing-addon1"><span class="glyphicon glyphicon-lock"></span></span>
			  			<input type="password" class="form-control" placeholder="Password" aria-describedby="sizing-addon1" name="cust_pass" required>
					</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary" name="submit">Login</button>
						<button type="button" class="btn btn-info" data-dismiss="modal">Cancel</button>
					</div>
				</form>
				</div>
			</div>
		</div>
		
		<?php 
			if(!isset($_POST['cust_user']) && !isset($_POST['cust_pass'])) {
					//No codes to run
				} else {
					$c = oci_pconnect(ORA_CON_UN,ORA_CON_PW,ORA_CON_DB);
					$s = oci_parse($c, 'SELECT cust_user FROM customer WHERE cust_user = :cust_user_bv AND cust_pass = :cust_pass_bv');
					oci_bind_by_name($s, ":cust_user_bv", $_POST['cust_user']);
					oci_bind_by_name($s, ":cust_pass_bv", $_POST['cust_pass']);
					oci_execute($s);
					$r = oci_fetch_array($s, OCI_ASSOC);

					if ($r) {
						$_SESSION['cust_user'] = $_POST['cust_user'];
						
							echo "<script>window.open('gallery.php','_self')</script>";
							oci_close($c);
					}
					 else {
					 	echo "<script>alert('Invalid Username or Password!')</script>";
					 	oci_close($c);

					 } 

				}
		?>

		<?php /* Page Footer */ include("includes/footer.php"); ?>

		<?php /* Modal contact Form */ include("includes/contact_form.php"); ?>

</body>
</html>