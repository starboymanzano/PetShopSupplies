<?php 
	session_start();
	include("functions.php");
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>About Us - M&M Pet Supplies</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- If computer has running through internet
		<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="custom-css/custom.css">
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	-->
	
	<!-- If computer doesn't access internet -->
	    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="custom-css/custom.css">
	    <script src="bootstrap-3.3.7-dist/js/jquery.min.js"></script>
	    <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</head>

<body>
	<nav class="navbar navbar-inverse lewis-header">
		<div class="container">

			<!--logo -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="index.php" class="navbar-left"><img src="media/header.png"></a>
			</div>

			<!--menu-items -->
			<div class="collapse navbar-collapse" id="mainNavBar">
				<?php 
	
					if(isset($_SESSION['cust_user'])){
					echo "<ul class='nav navbar-nav'><li>
						<form method='get' action='results.php' role='search' class='navbar-form col-xs-12' enctype='multipart/form-data'>
						<input name='search' type='search' class='form-control' placeholder='Search from shop'/>
						<input name='search-btn' type='submit' class='btn btn-primary' value='Search'/>
						</form>
						</li></ul>";
					} else {
						//Oh yeah!
					}
					?>

				<!--right align -->
				<ul class="nav navbar-nav navbar-right">
					<li><a href="index.php">Home</a></li>
				
					<!--drop down menu -->
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Info <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<?php 
								if(isset($_SESSION['cust_user'])) {
									echo "<li><a href='#contact' data-toggle='modal'>Contact</a></li>";
								} else {
									//No Codes
								}
							?>
							<li><a href="feedback.php">Feedbacks</a></li>
							<li class="active"><a href="about.php">About Us</a></li>
							<li><a href="gallery.php">Gallery</a></li>
						</ul>
					</li>
					<?php
						if (isset($_SESSION['cust_user'])) {
							echo "<li><a href='shop.php'>Shop</a></li>";
						} else {
							echo "<li><a href='#login' data-toggle='modal'>Shop</a></li>";
						}
					?>
				
					<li><a href="#">Cart</a></li>

					<!--drop down menu -->
					<?php 
						if (!isset($_SESSION['cust_user'])) {
	    					echo "<li><a href='#login' data-toggle='modal'>Login/Register</a></li>";
						 } else {
						 	echo "<li class='dropdown'>
							<a href='#'' class='dropdown-toggle' data-toggle='dropdown'>Hi, " . $_SESSION['cust_user'] . "<span class='caret'></span></a>
							<ul class='dropdown-menu'>
							<li><a href='myaccount.php'>Account Page</a></li>
							<li><a href='logout.php'>Logout</a></li>
							</ul>
							</li>";
						 }
					 ?>
				</ul>

			</div>
		</div>
	</nav>

	<div class="container">
		<div class="row">
			<div class="col-md-10">
				<ul class="breadcrumb">
					<li><a href="index.php">Home</a></li>
					<li class="disabled">Information Section</li>
					<li class="active">About Us</li>						
				</ul>
				<div class="panel panel-primary" style="background-color: #F2F1EF;">
					
					<div class="panel-body">
					
						<div class="page-header">
							<h1>About Us</h1>
						</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-11">
								<p><img class="img-responsive" src="media/header.png"/></p>
								<p><h3 class="text-center">Our Mission</h3></p>
								<p class="text-center">
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
								</p>
								<p><br/></p>
								<p><h3 class="text-center">Our Vision</h3></p>
								<p class="text-center">
									It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
								</p>
								<p><br/><hr/></p>
								<p><h3 class="text-center">History</h3></p>
								<p class="text-center">
									Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.
								</p><br/>
								<p class="text-center">
									The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.
								</p><br/>
								<p><h3 class="text-center">Location</h3></p>
								<p class="text-center">
									Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.
								</p><br/>
								<hr/>
								
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>

			<?php /* Ads Section */ include("includes/ads.php"); ?>

		
	</div>
	</div>
	
	<div class="modal fade" id="login" role="dialog">
	<div class="modal-dialog">
				<div class="modal-content">
					<form role="form" class="form-horizontal" method="post">
					<div class="modal-header">
						<h4 style="margin-left: 10px;">You need to Login before accessing the shop</h4>
					</div>
					
					<div class="modal-body">
					<div class="alert alert-info">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times</a>Don't have an account? Register <a href="registration.php">here</a>
					</div>
						<div class="input-group input-group-lg">
			 			 <span class="input-group-addon" id="sizing-addon1">@</span>
			  			<input type="text" class="form-control" placeholder="Username" aria-describedby="sizing-addon1" name="cust_user" required>
					</div><br/>			
					<div class="input-group input-group-lg">
			 			 <span class="input-group-addon" id="sizing-addon1"><span class="glyphicon glyphicon-lock"></span></span>
			  			<input type="password" class="form-control" placeholder="Password" aria-describedby="sizing-addon1" name="cust_pass" required>
					</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary" name="submit">Login</button>
						<button type="button" class="btn btn-info" data-dismiss="modal">Cancel</button>
					</div>
				</form>
				</div>
			</div>
		</div>
		
		<?php 
			if(!isset($_POST['cust_user']) && !isset($_POST['cust_pass'])) {
					//No codes to run
				} else {
					$c = oci_pconnect(ORA_CON_UN,ORA_CON_PW,ORA_CON_DB);
					$s = oci_parse($c, 'SELECT cust_user FROM customer WHERE cust_user = :cust_user_bv AND cust_pass = :cust_pass_bv');
					oci_bind_by_name($s, ":cust_user_bv", $_POST['cust_user']);
					oci_bind_by_name($s, ":cust_pass_bv", $_POST['cust_pass']);
					oci_execute($s);
					$r = oci_fetch_array($s, OCI_ASSOC);

					if ($r) {
						$_SESSION['cust_user'] = $_POST['cust_user'];
						
							echo "<script>window.open('about.php','_self')</script>";
							oci_close($c);
					}
					 else {
					 	echo "<script>alert('Invalid Username or Password!')</script>";
					 	oci_close($c);

					 } 

				}
		?>

		<?php /* Page Footer */ include("includes/footer.php"); ?>

		<?php /* Modal contact Form */ include("includes/contact_form.php"); ?>

</body>
</html>