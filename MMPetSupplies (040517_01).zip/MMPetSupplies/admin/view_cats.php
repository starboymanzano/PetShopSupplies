<?php
	session_start();
?>
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
		<div class="panel panel-primary">
			<div class="panel-heading">List of Categories</div>

			<table class="table table-striped table-hover">
				<tr>	
					<th>Category No.</th>
					<th>Category Name</th>
					<th>Action</th>
				</tr>
				
				<?php 
					$get_cat = "SELECT * FROM categories ORDER BY category_id";

					$run_cat = oci_parse($con, $get_cat);
					oci_execute($run_cat);
					
					while ($row_cat = oci_fetch_array($run_cat)) {

					$cat_id    = $row_cat['CATEGORY_ID'];
					$cat_title = $row_cat['CATEGORY_NAME'];
			
					
				?>
				
				<tr>
					<td><?php echo $cat_id; ?></td>
					<td><?php echo $cat_title; ?></td>
					<td>
						<span><a href="index.php?edit_cat=<?php echo $cat_id ?>">Edit</a></span> / 
						<span><a href="delete_cat.php?delete_cat=<?php echo $cat_id ?>">Delete</a></span>
					</td>
					
				</tr>
				
				<?php 
					}
					
					oci_free_statement($run_cat);
					oci_close($con);
					
					if (isset($_GET['delete_cat'])) {
						include("delete_cat.php");
					}
		?>
		
			</table>
		</div>
	</div>

	<div class="col-md-2"></div>
 </div>