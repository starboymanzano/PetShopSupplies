<?php
	session_start();
?>
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
		<div class="panel panel-success">
			<div class="panel-heading">List of Type of Animals</div>

			<table class="table table-striped table-hover">
				<tr>	
					<th>Type No.</th>
					<th>Type Name</th>
					<th>Action</th>
				</tr>
				
				<?php 
					$get_toa = "SELECT * FROM animals ORDER BY animal_id";

					$run_toa = oci_parse($con, $get_toa);
					oci_execute($run_toa);
					
					while ($row_toa = oci_fetch_array($run_toa)) {

					$toa_id    = $row_toa['ANIMAL_ID'];
					$toa_title = $row_toa['ANIMAL_NAME'];
			
					
				?>
				
				<tr>
					<td><?php echo $toa_id; ?></td>
					<td><?php echo $toa_title; ?></td>
					<td>
						<span><a href="index.php?edit_toa=<?php echo $toa_id ?>">Edit</a></span> / 
						<span><a href="delete_toa.php?delete_toa=<?php echo $toa_id ?>">Delete</a></span>
					</td>
					
				</tr>
				
				<?php 
					}
					
					oci_free_statement($run_toa);
					oci_close($con);
					
					if (isset($_GET['delete_toa'])) {
						include("delete_toa.php");
					}
		?>
		
			</table>
		</div>
	</div>

	<div class="col-md-2"></div>
 </div>