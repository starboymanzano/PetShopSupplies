<?php
	session_start();
?>
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
		<div class="panel panel-success">
			<div class="panel-heading">Edit Type</div>
		
			<div class="panel-body">
				<?php 
					if (isset($_GET['edit_toa'])) {

					$get_toa_id = $_GET['edit_toa'];

					$get_toa = "SELECT * FROM animals WHERE animal_id='$get_toa_id'";

					$run_toa = oci_parse($con, $get_toa);
					
					oci_execute($run_toa);

					$row_toa = oci_fetch_array($run_toa);

					$toa_title = $row_toa['ANIMAL_NAME'];
					

				}
 ?>


<form class="form-horizontal" method="post"> 
	<strong>Update Type:</strong><br/>
	<input type="text" name="new_toa" value="<?php echo $toa_title ?>" required /><br/><hr/>
	<input class="btn btn-success" type="submit" name="update_toa" value="Update" />
</form>

<?php 

	if (isset($_POST['update_toa'])) {

		$update_id = $get_toa_id;

		$new_toa = $_POST['new_toa'];

		$update_toa = "UPDATE animals SET animal_name='$new_toa' WHERE animal_id='$update_id'";

		$run_toa = oci_parse($con, $update_toa);
		oci_execute($run_toa);

		if ($run_toa) {

			echo "<script>alert('Type has been updated')</script>";
			echo "<script>window.open('index.php?view_toa','_self')</script>";

		}

	}

 ?>
			</div>
			
		</div>
	</div>

	<div class="col-md-2"></div>
 </div>