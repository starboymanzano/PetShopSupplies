<?php
	session_start();
?>
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
		<div class="panel panel-primary">
			<div class="panel-heading">Edit Category</div>
		
			<div class="panel-body">
				<?php 
					if (isset($_GET['edit_cat'])) {

					$get_cat_id = $_GET['edit_cat'];

					$get_cat = "SELECT * FROM categories WHERE category_id='$get_cat_id'";

					$run_cat = oci_parse($con, $get_cat);
					
					oci_execute($run_cat);

					$row_cat = oci_fetch_array($run_cat);

					$cat_title = $row_cat['CATEGORY_NAME'];
					

				}
 ?>


<form class="form-horizontal" method="post"> 
	<strong>Update Category:</strong><br/>
	<input type="text" name="new_cat" value="<?php echo $cat_title ?>" required /><br/><hr/>
	<input class="btn btn-success" type="submit" name="update_cat" value="Update Category" />

</form>

<?php 

	if (isset($_POST['update_cat'])) {

		$update_id = $get_cat_id;

		$new_cat = $_POST['new_cat'];

		$update_cat = "UPDATE categories SET category_name='$new_cat' WHERE category_id='$update_id'";

		$run_cat = oci_parse($con, $update_cat);
		oci_execute($run_cat);

		if ($run_cat) {

			echo "<script>alert('Category has been updated')</script>";
			echo "<script>window.open('index.php?view_category','_self')</script>";

		}

	}

 ?>
			</div>
			
		</div>
	</div>

	<div class="col-md-2"></div>
 </div>