<?php 
	session_start();
?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-warning">
					<div class="panel-heading">Create a new Administrator Account</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-10">
								<form method="post" class="form-horizontal">
									<p>New Admin Username: <input type="text" name="input_adminuser" /></p>
									<p>New Admin Password: <input type="password" name="input_adminpw" /></p>
									<hr/>
									<p><input class="btn btn-success" type="submit" name="create_acc" value="Create Account" /></p>
								</form>
								
								<?php 
									if(isset($_POST['create_acc'])) {
										
										$query = "INSERT INTO admin (admin_username, admin_password) VALUES (:adminuser_name_bv, :adminpw_name_bv)";
										$run_query = oci_parse($con, $query);
										
										oci_bind_by_name($run_query, ":adminuser_name_bv", $_POST["input_adminuser"]);
										oci_bind_by_name($run_query, ":adminpw_name_bv", $_POST["input_adminpw"]);
										
										oci_execute($run_query);
										
										echo "<script>alert('Admin account created successfully!')</script>";
										
										
									}
								?>
								
								<hr/>
								
								<div class="panel-heading"><h3>Admin Accounts</h3></div>

									<table class="table table-bordered table-striped table-hover">
										<tr class="active">	
											<th>Admin Username</th>
											<th>Admin Password</th>
											<th>Action</th>
										</tr>
				
										<?php 
											$get_admin = "SELECT * FROM admin";

											$run_admin = oci_parse($con, $get_admin);
											oci_execute($run_admin);
											
											while ($row_admin = oci_fetch_array($run_admin)) {

											$admin_user = $row_admin['ADMIN_USERNAME'];
											$admin_pass = $row_admin['ADMIN_PASSWORD'];
									
											
										?>
										
										<tr>
											<td><?php echo $admin_user; ?></td>
											<td style="-webkit-text-security: disc;"><?php echo "$!@$^&S" . $admin_pass; ?></td>
											<td>
												<span><a href="index.php?edit_admin=<?php echo $admin_user ?>">Change Password</a></span> / 
												<span><a href="delete_admin.php?delete_admin=<?php echo $admin_user ?>">Remove Account</a></span>
											</td>
											
										</tr>
										
										<?php 
											}
											
											oci_free_statement($run_admin);
											oci_close($con);
											
											if (isset($_GET['delete_admin'])) {
												include("delete_admin.php");
											}
								?>
								
									</table>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
		