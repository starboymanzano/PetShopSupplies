<?php
	session_start();
?>
 <div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-8">
		<div class="panel panel-danger">
			<div class="panel-heading">Change Password</div>
		
			<div class="panel-body">
			
			<?php 
				if (isset($_GET['edit_admin'])) {

					$get_adm_user = $_GET['edit_admin'];
				
				}
			?>
			
			<form class="form-horizontal" method="post"> 
				<strong>New Password:</strong><br/>
				<input type="password" name="new_pw" required /><br/><br/>
				<strong>Confirm Password:</strong><br/>
				<input type="password" name="again_pw" required /><br/><hr/>
				<input class="btn btn-danger" type="submit" name="update_pass" value="Change Password" />
				<br/><hr/><br/>
			</form>

			<?php 
				
				if (isset($_POST['update_pass'])) {

					$update_adm = $get_adm_user;

					$new_pw = $_POST['new_pw'];

					$update_pw = "UPDATE admin SET admin_password='$new_pw' WHERE admin_username='$get_adm_user'";

					$run_cat = oci_parse($con, $update_pw);
					
					
					
					if (!($_POST['new_pw'] == $_POST['again_pw'])) {
						echo "<div class='alert alert-warning'>
								<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times</a>Password not the same</a>
								</div>";
						exit();
					} 
					
					oci_execute($run_cat);
					
					if ($run_cat) {

						echo "<script>alert('Password has been changed!')</script>";
						echo "<script>window.open('index.php?admin_page','_self')</script>";

					}
					
					
				}

			 ?>
						</div>
						
					</div>
				</div>

				<div class="col-md-2"></div>
			 </div>