<?php 
	session_start();
?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">Add Category</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-10">
								<form method="post" class="form-horizontal">
									<p>Add New Category: </p>
										<p><input type="text" name="input_cat" /></p>
										<p><input class="btn btn-success" type="submit" name="add_cat" value="Add Category" /></p>
								</form>
								
								<?php 
									if(isset($_POST['add_cat'])) {
										
										$query = "INSERT INTO categories (category_name) VALUES (:category_name_bv)";
										$run_query = oci_parse($con, $query);
										
										oci_bind_by_name($run_query, ":category_name_bv", $_POST["input_cat"]);
										
										oci_execute($run_query);
										
										echo "<script>alert('New category has been added!')</script>";
										echo "<script>window.open('index.php?view_category','_self')</script>";
										
										oci_free_statement($run_query);
										oci_close($con);
										
									}
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		