<?php 
	include("../functions.php");
	
 	if (isset($_GET['delete_cat'])) {

 		$delete_id = $_GET['delete_cat'];

 		$delete_cat = "DELETE from categories WHERE category_id='$delete_id'";

 		$run_delete = oci_parse($con, $delete_cat);
		oci_execute($run_delete);

 		if ($run_delete) {

		 		echo "<script>alert('Category has been deleted')</script>";

		 		echo "<script>window.open('index.php?view_category','_self')</script>";
 	
	 	}
	 	
 	}
  ?>