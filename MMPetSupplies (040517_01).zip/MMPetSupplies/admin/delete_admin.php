<?php 
	include("../functions.php");
	
 	if (isset($_GET['delete_admin'])) {

 		$delete_get = $_GET['delete_admin'];

 		$delete_user = "DELETE from admin WHERE admin_username='$delete_get'";

 		$run_delete = oci_parse($con, $delete_user);
		oci_execute($run_delete);

 		if ($run_delete) {

		 		echo "<script>alert('This admin account has been deleted')</script>";

		 		echo "<script>window.open('index.php?admin_page','_self')</script>";
 	
	 	}
	 	
 	}
  ?>