<?php 
	include("../functions.php");
	
 	if (isset($_GET['delete_toa'])) {

 		$delete_id = $_GET['delete_toa'];

 		$delete_toa = "DELETE from animals WHERE animal_id='$delete_id'";

 		$run_delete = oci_parse($con, $delete_toa);
		oci_execute($run_delete);

 		if ($run_delete) {

		 		echo "<script>alert('Type has been deleted')</script>";

		 		echo "<script>window.open('index.php?view_toa','_self')</script>";
 	
	 	}
	 	
 	}
  ?>