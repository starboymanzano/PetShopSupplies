<?php 
	include("../functions.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin Page - M&M Pet Supplies</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- If computer has running through internet
		<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="custom-css/custom.css">
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	-->
	
	<!-- If computer doesn't access internet -->
	    <link rel="stylesheet" type="text/css" href="../bootstrap-3.3.7-dist/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../custom-css/admin.css">
	    <script src="../bootstrap-3.3.7-dist/js/jquery.min.js"></script>
	    <script src="../bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
		<script src="../tinymce/js/tinymce/tinymce.min.js"></script>
		
</head>

<body>

	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
			<!--logo -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="index.php" class="navbar-left"><img src="01-ADMIN.PNG" /></a>
			</div>
			<!--menu-items -->
			<div class="collapse navbar-collapse" id="mainNavBar">
				<ul class="nav navbar-nav">
					<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Admin Home</a></li>
				
					<!--drop down menu -->
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> Users <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href='?admin_page'>Admin Account Section</a></li>
							<li class="divider"></li>
							<li><a href="feedback.php">Customers Account List</a></li>
						</ul>
					</li>
					
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-leaf"></span> Products/Supplies <span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href='?add_product'>Add Products/Supplies</a></li>
							<li><a href='?view_products'>View All Products/Supplies</a></li>
							<li class="divider"></li>
							<li><a href='?add_category'>Add Category</a></li>
							<li><a href='?add_toa'>Add Types of Animal</a></li>
							<li><a href='?view_category'>View All Categories</a></li>
							<li><a href='?view_toa'>View All Types of Animal</a></li>

						</ul>
					</li>
					
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-shopping-cart"></span> Transactions <span class="caret"></span></a>
						<ul class="dropdown-menu">
						
						</ul>
					</li>
				</ul>

			</div>
		</div>
	</nav>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">Admin Page</div>
					<div class="panel-body">
						<?php 
							if (isset($_GET['add_product'])) {
								include("add_product.php");
							}

							if (isset($_GET['view_products'])) {
								include("view_products.php");
							}

							if (isset($_GET['edit_prod'])) {
								include("edit_prod.php");
							}

							if (isset($_GET['add_category'])) {
								include("add_category.php");
							}

							if (isset($_GET['view_category'])) {
								include("view_cats.php");
							}

							if (isset($_GET['edit_cat'])) {
								include("edit_cat.php");
							}

							if (isset($_GET['add_toa'])) {
								include("add_toa.php");
							}

							if (isset($_GET['view_toa'])) {
								include("view_toa.php");
							}

							if (isset($_GET['edit_toa'])) {
								include("edit_toa.php");
							}

							if (isset($_GET['view_customers'])) {
								include("view_customers.php");
							}
							
							if (isset($_GET['admin_page'])) {
								include("admin.php");
							}
							
							if (isset($_GET['edit_admin'])) {
								include("admin_edit.php");
							}
						?>
					</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>tinymce.init({ selector:'textarea' });</script>

</body>
</html>