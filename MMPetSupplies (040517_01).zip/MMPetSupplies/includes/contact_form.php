
<div class="modal fade" id="contact" role="dialog">
	<div class="modal-dialog">
				<div class="modal-content">
					<form class="form-horizontal" method="post">
					<div class="modal-header">
						<h4>Contact our Store</h4>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<label for="contact-name" class="col-lg-2 control-label">Name:</label>
							<div class="col-lg-10">
								<input type="text" class="form-control disable" placeholder="Full Name" name="full_name" value="<?php echo $_SESSION['cust_user']; ?>" readonly />
							</div>

						</div>
						<div class="form-group">
							<label for="contact-email" class="col-lg-2 control-label">Email:</label>
							<div class="col-lg-10">
								<input type="email" class="form-control " placeholder="you@example.com" name="full_email" value="<?php 	
								
											$session_user = $_SESSION['cust_user'];
											
											$query = "SELECT cust_email FROM customer WHERE cust_user = '$session_user'";
											$sql = oci_parse($con, $query);
											oci_execute($sql);
									
											$row = oci_fetch_array($sql, OCI_ASSOC);
											$email = $row['CUST_EMAIL'];
						
											$_SESSION['cust_email'] = $email;
						
											echo $_SESSION['cust_email']?>" readonly />
							</div>
						</div>
						<div class="form-group">
							<label for="contact-msg" class="col-lg-2 control-label">Message:</label>
							<div class="col-lg-10">
								<textarea class="form-control" row="8" placeholder="Your Message" name="full_message"></textarea>
							</div>
						</div>

					</div>
					<div class="modal-footer">
						<button type="submit" name="send_feedback" class="btn btn-primary">Send</button>
						<button type="button" class="btn btn-info" data-dismiss="modal">Cancel</button>
					</div>
					
					<?php 
						if (!isset($_POST["send_feedback"])) {
							//No codes
						} else {
							$run_query = oci_parse($con, "INSERT INTO feedbacks (f_fullname, f_email, f_message, f_date) VALUES (:full_name_bv , :full_email_bv, :full_message_bv, :full_time_bv)");
						
						date_default_timezone_set("Asia/Singapore");
						$date = date('F j, Y, g:i a', time());
	
						oci_bind_by_name($run_query, ":full_name_bv", $_POST['full_name']);
						oci_bind_by_name($run_query, ":full_email_bv", $_POST['full_email']);
						oci_bind_by_name($run_query, ":full_message_bv", $_POST['full_message']);
						oci_bind_by_name($run_query, ":full_time_bv", $date);
						
					
						oci_execute($run_query);
						echo "<script>alert('Thank you for feedback us!, if this is a positive response, we will post it on our feedback page');</script>";
						
						
					}
		?>

				</form>
				</div>
			</div>
		</div>
		
		
