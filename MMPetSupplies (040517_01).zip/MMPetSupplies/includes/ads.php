<div class="col-md-2">
	<img src="media/ads.gif"/>
</div>