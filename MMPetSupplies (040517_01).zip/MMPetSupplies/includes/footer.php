<div class="navbar navbar-default navbar-static-bottom">
		<div class="container">
			<p class="navbar-text pull-left">&copy 2017, M&M Online PetShop</p>
			<a class="navbar-btn btn btn-primary pull-right">Follow us on Facebook</a>
		</div>
	</div>